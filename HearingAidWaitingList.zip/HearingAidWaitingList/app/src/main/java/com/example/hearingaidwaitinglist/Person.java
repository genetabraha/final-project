package com.example.hearingaidwaitinglist;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Person {
    @PrimaryKey
    public int person_id;

    @ColumnInfo(name = "person_name")
    public String person_name;

    @ColumnInfo(name = "contactno")
    public String contactno;

    @ColumnInfo(name = "gender")
    public String gender;

    public Person(int person_id , String person_name, String contactno, String gender) {
        this.person_id = person_id;
        this.person_name = person_name;
        this.contactno = contactno;
        this.gender = gender;
    }
}

