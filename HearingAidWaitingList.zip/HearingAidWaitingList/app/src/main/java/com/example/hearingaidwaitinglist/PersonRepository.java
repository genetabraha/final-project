package com.example.hearingaidwaitinglist;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.room.Room;

import java.util.List;

public class PersonRepository {
    private static PersonDatabase personDatabase;
    private static Context context;
    private String DB_NAME = "persondb";

    public PersonRepository(Context context){
        this.context = context;
        personDatabase = Room.databaseBuilder(context, PersonDatabase.class, DB_NAME).build();

    }

    public static void InsertTask(final Person person)
    {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                personDatabase.personDao().insertTask(person);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(context, person.person_name+ " registered successfully", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }

    public List<Person> getPersons(){
        List<Person>personList = personDatabase.personDao().getAll();
        return personList;
    }


    //--UpdateTask----
    public static void UpdateTask(final Person person)
    {
        new AsyncTask<Void, Void, Void>(){
            @Override
            protected Void doInBackground(Void... voids) {
                personDatabase.personDao().updateTask(person);
                return null;
            }
        }.execute();
    }


    //--DeleteTask--
    public static void DeleteTask(final Person person)
    {
        new AsyncTask<Void, Void, Void>(){
            @Override
            protected Void doInBackground(Void... voids) {
                personDatabase.personDao().deleteTask(person);
                return null;
            }
        }.execute();
    }


}

