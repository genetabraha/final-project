package com.example.hearingaidwaitinglist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ViewActivity extends AppCompatActivity {
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private  static RecyclerView recyclerView;
    ArrayList<Person>personArrayList,personArrayList_search;
    EditText edt_search;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        recyclerView = (RecyclerView)findViewById(R.id.person_recycler_view);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        edt_search = (EditText)findViewById(R.id.edt_search);

        edt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString();
                filter(text);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        new LoadDataTask().execute();
    }
    class LoadDataTask extends AsyncTask<Void, Void, Void>
    {
        PersonRepository personRepository;
        List<Person> personList;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            personRepository= new PersonRepository(getApplicationContext());
        }

        @Override
        protected Void doInBackground(Void... voids) {
            personList = personRepository.getPersons();
            personArrayList = new ArrayList<>();
            personArrayList_search = new ArrayList<>();


            for (int i=0; i<personList.size(); i++)
            {
                personArrayList.add(personList.get(i));
                personArrayList_search.add(personList.get(i));
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            customAdapter = new CustomAdapter(personArrayList, ViewActivity.this);
            recyclerView.setAdapter(customAdapter);
        }
    }


    public void filter(String charText)
    {
        charText = charText.toLowerCase(Locale.getDefault());
        Log.d("filter", charText+"");

        personArrayList.clear();

        if (charText.length() ==0)
        {
            personArrayList.addAll(personArrayList_search);
            Log.d("laod data","All");
        }
        else
        {
            Log.d("load data", "Filtered");
            for (Person person:personArrayList_search)
            {
                if (person.person_name.toLowerCase(Locale.getDefault()).contains(charText)
                        || String.valueOf(person.person_id).toLowerCase(Locale.getDefault()).contains(charText))
                {
                    personArrayList.add(person);
                }
            }
        }
        customAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        new LoadDataTask().execute();
    }
}