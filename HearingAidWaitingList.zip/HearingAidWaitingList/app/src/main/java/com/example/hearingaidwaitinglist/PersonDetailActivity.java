package com.example.hearingaidwaitinglist;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class PersonDetailActivity extends AppCompatActivity {
    EditText edt_person_id, edt_person_name, edt_contactno;
    Button btn_update, btn_delete;

    int sperson_id;
    String sperson_name ="", scontactno = "", sgender = "";

    String sperson_id_to_update = "", sperson_name_to_update = "", scontactno_to_update = "", sgender_to_update = "";
    String sperson_id_to_delete = "", sperson_name_to_delete = "", scontactno_to_delete = "", sgender_to_delete = "";

    RadioButton rbtn_male, rbtn_female;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_detail);


        edt_person_id = (EditText)findViewById(R.id.edt_person_id);
        edt_person_name = (EditText)findViewById(R.id.edt_person_name);
        edt_contactno = (EditText)findViewById(R.id.edt_contactno);
        rbtn_male = (RadioButton)findViewById(R.id.rbtn_male);
        rbtn_female = (RadioButton)findViewById(R.id.rbtn_female);

        btn_update = (Button)findViewById(R.id.btn_update);
        btn_delete = (Button)findViewById(R.id.btn_delete);


        Bundle data = getIntent().getExtras();
        if (data!=null)
        {
            sperson_id = data.getInt("person_id");
            sperson_name = data.getString("person_name");
            scontactno = data.getString("contactno");
            sgender = data.getString("gender");
        }

        edt_person_id.setText(sperson_id+"");
        edt_person_name.setText(sperson_name+"");
        edt_contactno.setText(scontactno+"");

        if(sgender.trim().toLowerCase().equalsIgnoreCase("Male"))
        {
            rbtn_male.setChecked(true);
        }

        else if(sgender.trim().toLowerCase().equalsIgnoreCase("Female"))
        {
            rbtn_female.setChecked(true);
        }


        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edt_person_name.getText().toString().isEmpty()
                        || edt_contactno.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"please put all details", Toast.LENGTH_LONG);
                }
                else
                {
                    sperson_id_to_update = edt_person_id.getText().toString().trim();
                    sperson_name_to_update = edt_person_name.getText().toString().trim();
                    scontactno_to_update = edt_contactno.getText().toString().trim();

                    if (rbtn_male.isChecked())
                    {
                        sgender_to_update = "Male";
                    }

                    else if (rbtn_female.isChecked())
                    {
                        sgender_to_update = "Female";
                    }

                    PersonRepository personRepository = new PersonRepository(getApplicationContext());
                    Person person= new Person(Integer.parseInt(sperson_id_to_update), sperson_name_to_update, scontactno_to_update, sgender_to_update);
                    personRepository.UpdateTask(person);
                    Toast.makeText(getApplicationContext(), "Value Updated!", Toast.LENGTH_LONG).show();
                    finish();

                }

            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sperson_id_to_delete = edt_person_id.getText().toString().trim();
                sperson_name_to_delete = edt_person_name.getText().toString().trim();
                scontactno_to_delete = edt_contactno.getText().toString().trim();
                if (rbtn_male.isChecked())
                {
                    sgender_to_delete = "Male";
                }

                if (rbtn_female.isChecked())
                {
                    sgender_to_delete = "Female";
                }

                Person person_to_delete = new Person(Integer.parseInt(sperson_id_to_delete), sperson_name_to_delete, scontactno_to_delete, sgender_to_delete);
                generate_delete_dialog(person_to_delete);

            }
        });
    }

    public void generate_delete_dialog(Person person)
    {
        final Person person_about_to_delete = person;
        AlertDialog.Builder builder = new AlertDialog.Builder(PersonDetailActivity.this, R.style.AppCompatAlertDialogStyle); // do not write getApplicationContext()
        builder.setTitle("Warning!");
        builder.setMessage("Are you sure you want to delete?\n"+"patient_id: "+person_about_to_delete.person_id+"\n"+"Name: "+person_about_to_delete.person_name);
        builder.setIcon(android.R.drawable.ic_delete);

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                PersonRepository personRepository = new PersonRepository(getApplicationContext());
                personRepository.DeleteTask(person_about_to_delete);
                Toast.makeText(PersonDetailActivity.this, "deleted successfully", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog deleteDialog = builder.create();
        deleteDialog.show();
    }
}