package com.example.hearingaidwaitinglist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {
    EditText edt_person_id, edt_person_name, edt_contactno;
    RadioButton rbtn_male, rbtn_female;

    Button btn_save;
    String sperson_id, sperson_name, scontactno, sgender = "Female";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        edt_person_id = findViewById(R.id.edt_person_id);
        edt_person_name = findViewById(R.id.edt_person_name);
        edt_contactno = findViewById(R.id.edt_contactno);
        rbtn_male = findViewById(R.id.rbtn_male);
        rbtn_female = findViewById(R.id.rbtn_female);

        btn_save = findViewById(R.id.btn_save);




        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edt_person_id.getText().toString().isEmpty()
                        || edt_person_name.getText().toString().isEmpty()
                        || edt_contactno.getText().toString().isEmpty()) {

                    Toast.makeText(getApplicationContext(), "Pease fill in all information", Toast.LENGTH_LONG).show();
                }
                else
                {
                    sperson_id = edt_person_id.getText().toString().trim();
                    sperson_name = edt_person_name.getText().toString().trim();
                    scontactno = edt_contactno.getText().toString().trim();

                    if (rbtn_female.isChecked())
                    {
                        sgender = "Male";
                    }
                    else
                    {
                        sgender = "Female";
                    }

                    PersonRepository personRepository = new PersonRepository(getApplicationContext());
                   Person person = new Person(Integer.parseInt(sperson_id), sperson_name, scontactno, sgender);
                    PersonRepository.InsertTask(person);

                    edt_person_id.setText("");
                    edt_person_name.setText("");
                    edt_contactno.setText("");
                }
            }

        });
    }

}