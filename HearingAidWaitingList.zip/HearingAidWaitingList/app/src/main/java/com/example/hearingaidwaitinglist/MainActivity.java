package com.example.hearingaidwaitinglist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btn_insert, bnt_view;

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn_insert = (Button)findViewById(R.id.btn_insert);
        bnt_view= (Button)findViewById(R.id.btn_view);



        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent is = new Intent(MainActivity.this,InsertActivity.class);
                startActivity(is);
            }
        });

        bnt_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iv = new Intent(MainActivity.this,ViewActivity.class);
                startActivity(iv);
            }
        });
    }

}