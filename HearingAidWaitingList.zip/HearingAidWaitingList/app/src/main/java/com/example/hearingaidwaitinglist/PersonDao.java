package com.example.hearingaidwaitinglist;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PersonDao {
    @Insert
    Long insertTask(Person person);

    @Update
    void updateTask(Person person);

    @Delete
    void deleteTask(Person person);
    @Query("select * from  person order by person_id asc")
    List<Person> getAll();
}
